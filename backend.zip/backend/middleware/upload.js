const multer = require('multer');

const storage = multer.memoryStorage();

const fileFilter = (req, file, cb) => {
  if (file.mimetype.startsWith('image/')) {
    cb(null, true);
  } else {
    cb(new Error('Apenas imagens são permitidas'), false);
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
});

// Upload múltiplo de imagens (documentos de cliente)
const uploadImages = upload.fields([
  { name: 'foto_usuario', maxCount: 1 },
  { name: 'documento_frente', maxCount: 1 },
  { name: 'documento_verso', maxCount: 1 },
  { name: 'selfie', maxCount: 1 },
]);

// Upload de documentos profissionais (CNH, documento do veículo, etc.)
const uploadProfessionalDocs = upload.fields([
  { name: 'documentos_profissionais', maxCount: 10 },
]);

module.exports = { uploadImages, uploadProfessionalDocs };
