import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';
import '../services/push_notification_service.dart';

/// Estado do profissional logado + autenticação e disponibilidade.
///
/// CORRIGIDO: não existia nenhum método de login/cadastro aqui - a tela de
/// login (telas/login.dart) nunca persistia sessão de profissional nenhuma.
class ProfissionalProvider with ChangeNotifier {
  String? _token;
  String? _userId;
  String? _userName;
  String? _userEmail;
  bool _twoFactorEnabled = false;
  bool _isOnline = false;
  bool _hasActiveRide = false;
  String? _lastError;

  String? get token => _token;
  String? get userId => _userId;
  String? get userName => _userName;
  String? get userEmail => _userEmail;
  bool get twoFactorEnabled => _twoFactorEnabled;
  bool get isOnline => _isOnline;
  bool get hasActiveRide => _hasActiveRide;
  String? get lastError => _lastError;

  bool get isAuthenticated => _token != null;

  Future<void> loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('token');
    _userId = prefs.getString('userId');
    _userName = prefs.getString('userName');
    _userEmail = prefs.getString('userEmail');
    _isOnline = prefs.getBool('isOnline') ?? false;
    notifyListeners();
  }

  Future<void> _persistSession(Map<String, dynamic> data) async {
    _token = data['token'] as String?;
    final refreshToken = data['refreshToken'] as String?;
    final user = data['user'] as Map<String, dynamic>?;
    _userId = user?['id']?.toString();
    _userName = user?['name']?.toString();
    _userEmail = user?['email']?.toString();
    _twoFactorEnabled = user?['two_factor_enabled'] == true;

    await ApiService.saveTokens(token: _token, refreshToken: refreshToken);
    // Best-effort: registra o token FCM deste dispositivo para este usuário.
    // Não faz nada se o Firebase não estiver configurado (ver serviço).
    PushNotificationService.instance.registerTokenWithBackend();
    final prefs = await SharedPreferences.getInstance();
    if (_userId != null) await prefs.setString('userId', _userId!);
    if (_userName != null) await prefs.setString('userName', _userName!);
    if (_userEmail != null) await prefs.setString('userEmail', _userEmail!);

    notifyListeners();
  }

  // --------------------------------------------------------------------
  // Autenticação
  // --------------------------------------------------------------------

  Future<Map<String, dynamic>> registrar({
    required String name,
    String? email,
    String? phone,
    String? cpf,
    required String password,
    required String especialidade,
    required String tipoVeiculoAtendido,
  }) async {
    final result = await ApiService.post('/auth/register', {
      'name': name,
      'email': email,
      'phone': phone,
      'cpf': cpf,
      'password': password,
      'role': 'profissional',
      'especialidade': especialidade,
      'tipo_veiculo_atendido': tipoVeiculoAtendido,
    });

    if (result['success'] == true) {
      await _persistSession(result);
    } else {
      _lastError = result['message']?.toString();
    }
    notifyListeners();
    return result;
  }

  Future<Map<String, dynamic>> iniciarLogin(String identifier, {bool preferSms = false}) async {
    final result = await ApiService.post('/auth/login/start', {
      'identifier': identifier,
      'role': 'profissional',
      'preferSms': preferSms,
    });
    if (result['success'] != true) _lastError = result['message']?.toString();
    notifyListeners();
    return result;
  }

  Future<Map<String, dynamic>> loginComSenha(String identifier, String password) async {
    final result = await ApiService.post('/auth/login/password', {
      'identifier': identifier,
      'password': password,
      'role': 'profissional',
    });

    if (result['success'] == true && result['requires2FA'] != true) {
      await _persistSession(result);
    } else if (result['success'] != true) {
      _lastError = result['message']?.toString();
    }
    notifyListeners();
    return result;
  }

  Future<Map<String, dynamic>> verificarCodigo(String identifier, String code) async {
    final result = await ApiService.post('/auth/verify', {
      'identifier': identifier,
      'code': code,
      'role': 'profissional',
    });

    if (result['success'] == true && result['requires2FA'] != true) {
      await _persistSession(result);
    } else if (result['success'] != true) {
      _lastError = result['message']?.toString();
    }
    notifyListeners();
    return result;
  }

  // Completa o login quando a conta tem 2FA ativado (ver ClienteProvider
  // para a explicação completa do fluxo - é idêntico para profissionais).
  Future<Map<String, dynamic>> verificarDoisFatores(String pendingToken, String code) async {
    final result = await ApiService.post('/auth/2fa/verify-login', {
      'pendingToken': pendingToken,
      'code': code,
    });

    if (result['success'] == true) {
      await _persistSession(result);
    } else {
      _lastError = result['message']?.toString();
    }
    notifyListeners();
    return result;
  }

  Future<Map<String, dynamic>> iniciarConfiguracao2FA() async {
    return ApiService.post('/auth/2fa/setup', {});
  }

  Future<Map<String, dynamic>> ativar2FA(String code) async {
    final result = await ApiService.post('/auth/2fa/enable', {'code': code});
    if (result['success'] == true) {
      _twoFactorEnabled = true;
      notifyListeners();
    }
    return result;
  }

  Future<Map<String, dynamic>> desativar2FA(String code) async {
    final result = await ApiService.post('/auth/2fa/disable', {'code': code});
    if (result['success'] == true) {
      _twoFactorEnabled = false;
      notifyListeners();
    }
    return result;
  }

  Future<void> reenviarCodigo(String identifier) async {
    await ApiService.post('/auth/resend-code', {'identifier': identifier});
  }

  // --------------------------------------------------------------------
  // Disponibilidade / corridas
  // --------------------------------------------------------------------

  // Atualizar status online (chama o backend e persiste localmente)
  Future<void> setOnline(bool online) async {
    _isOnline = online;
    notifyListeners();

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isOnline', online);

    await ApiService.put('/professionals/availability', {'disponivel': online});
  }

  void setActiveRide(bool active) {
    _hasActiveRide = active;
    notifyListeners();
  }

  // Logout
  Future<void> logout() async {
    final refreshToken = await ApiService.refreshToken;
    await ApiService.post('/auth/logout', {if (refreshToken != null) 'refreshToken': refreshToken});

    await PushNotificationService.instance.unregisterToken();
    await ApiService.clearTokens();
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    _token = null;
    _userId = null;
    _userName = null;
    _userEmail = null;
    _isOnline = false;
    _hasActiveRide = false;

    notifyListeners();
  }
}
